To enable class configs, put "setinfo ec 1" in your autoexec.cfg (located in your fortressone/fortress folder).

Place class configs in your fortressone/fortress folder.

Change "key" to a key of your choice.